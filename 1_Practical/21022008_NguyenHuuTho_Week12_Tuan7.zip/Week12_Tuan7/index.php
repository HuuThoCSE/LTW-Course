<form action="welcome.php" method="post">
    <label for="">Name:</label>
    <input type="text" name="name" id=""> <br>
    <label for="email">Email:</label>
    <input type="email" name="email" id=""> <br>
    <input type="submit" value="Submit" name="POSTsubmit">
</form>